package com.example.tracecam

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.hardware.camera2.*
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.view.*
import android.util.Size
import android.widget.*
import android.net.Uri
import android.provider.OpenableColumns
import java.io.InputStream
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var cameraView: TextureView
    private lateinit var overlayView: TraceOverlayView
    private lateinit var statusText: TextView
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var backgroundThread: HandlerThread? = null
    private var cameraHandler: Handler? = null
    private var previewSize = Size(1280, 720)
    private val requestCamera = 101
    private val pickImage = 102
    private var locked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startBackgroundThread()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), requestCamera)
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val vertical = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        val header = TextView(this).apply {
            text = "TRACECAM OFFLINE"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 14, 12, 14)
            setTypeface(null, Typeface.BOLD)
        }
        vertical.addView(header, LinearLayout.LayoutParams(-1, dp(52)))

        val stage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        cameraView = TextureView(this)
        stage.addView(cameraView, FrameLayout.LayoutParams(-1, -1))
        overlayView = TraceOverlayView(this)
        stage.addView(overlayView, FrameLayout.LayoutParams(-1, -1))
        vertical.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            setBackgroundColor(Color.rgb(15, 15, 15))
        }

        val buttons1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons1.addView(button("Choose photo") { openGallery() }, weightedButton())
        buttons1.addView(button("Lock: OFF") {
            locked = !locked
            overlayView.isLocked = locked
            (it as Button).text = if (locked) "Lock: ON" else "Lock: OFF"
            statusText.text = if (locked) "Image locked — tap Lock to move it again" else "Drag the image to align it over your paper"
        }, weightedButton())
        controls.addView(buttons1)

        val opacityLabel = label("Photo transparency")
        controls.addView(opacityLabel)
        val opacity = SeekBar(this).apply {
            max = 100
            progress = 45
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    overlayView.alphaValue = progress / 100f
                    opacityLabel.text = "Photo transparency: $progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(opacity, LinearLayout.LayoutParams(-1, dp(34)))

        val sizeLabel = label("Photo size")
        controls.addView(sizeLabel)
        val size = SeekBar(this).apply {
            max = 180
            progress = 70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    overlayView.scaleFactor = 0.4f + progress / 100f
                    sizeLabel.text = "Photo size: ${"%.1f".format(overlayView.scaleFactor)}×"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        controls.addView(size, LinearLayout.LayoutParams(-1, dp(34)))

        val buttons2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons2.addView(button("↶ Rotate") { overlayView.rotateBy(-5f) }, weightedButton())
        buttons2.addView(button("Rotate ↷") { overlayView.rotateBy(5f) }, weightedButton())
        buttons2.addView(button("Reset") { overlayView.resetTransform() }, weightedButton())
        controls.addView(buttons2)
        statusText = TextView(this).apply {
            text = "Choose a photo to start. Drag it to align with your paper."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, dp(6), 4, dp(2))
        }
        controls.addView(statusText)
        vertical.addView(controls, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(vertical)
        setContentView(root)

        cameraView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    private fun button(text: String, action: (View) -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 11f
            isAllCaps = false
            setOnClickListener(action)
        }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(Color.WHITE)
        setPadding(2, dp(3), 2, 0)
    }

    private fun weightedButton() = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        setMargins(dp(2), dp(2), dp(2), dp(2))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, pickImage)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { input ->
                    val bitmap = BitmapFactory.decodeStream(input)
                    if (bitmap != null) {
                        overlayView.setBitmap(bitmap)
                        statusText.text = "Photo loaded. Drag it to line up with your paper."
                    } else statusText.text = "Could not read that image."
                }
            } catch (e: Exception) {
                statusText.text = "Could not open the selected photo."
            }
        }
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("TraceCamCamera").also { it.start() }
        cameraHandler = Handler(backgroundThread!!.looper)
        if (cameraView.isAvailable) openCamera()
    }

    private fun openCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK
            } ?: manager.cameraIdList.first()
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    createPreview()
                }
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    runOnUiThread { statusText.text = "Camera error. Close and reopen the app." }
                }
            }, cameraHandler)
        } catch (e: Exception) {
            statusText.text = "Unable to open camera: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun createPreview() {
        val device = cameraDevice ?: return
        val texture = cameraView.surfaceTexture ?: return
        try {
            texture.setDefaultBufferSize(previewSize.width, previewSize.height)
            val surface = Surface(texture)
            val request = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            }
            device.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    try {
                        session.setRepeatingRequest(request.build(), null, cameraHandler)
                    } catch (_: Exception) {}
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    runOnUiThread { statusText.text = "Could not configure camera preview." }
                }
            }, cameraHandler)
        } catch (e: Exception) {
            runOnUiThread { statusText.text = "Camera preview failed." }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCamera) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startBackgroundThread()
                if (cameraView.isAvailable) openCamera()
            } else statusText.text = "Camera permission is required for tracing."
        }
    }

    override fun onResume() {
        super.onResume()
        if (backgroundThread == null && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startBackgroundThread()
        }
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    private fun closeCamera() {
        try { captureSession?.close() } catch (_: Exception) {}
        captureSession = null
        try { cameraDevice?.close() } catch (_: Exception) {}
        cameraDevice = null
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try { backgroundThread?.join() } catch (_: InterruptedException) {}
        backgroundThread = null
        cameraHandler = null
    }
}

private class TraceOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var bitmap: Bitmap? = null
    var alphaValue: Float = 0.45f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }
    var scaleFactor: Float = 1.1f
        set(value) { field = value.coerceIn(0.4f, 2.2f); invalidate() }
    var isLocked = false
    private var rotationDegrees = 0f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f

    fun setBitmap(newBitmap: Bitmap) {
        bitmap = newBitmap
        resetTransform()
    }

    fun rotateBy(degrees: Float) {
        if (!isLocked) { rotationDegrees += degrees; invalidate() }
    }

    fun resetTransform() {
        offsetX = 0f
        offsetY = 0f
        rotationDegrees = 0f
        scaleFactor = 1.1f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap ?: return
        val availableW = width * 0.78f
        val availableH = height * 0.78f
        val fit = min(availableW / b.width, availableH / b.height) * scaleFactor
        val w = b.width * fit
        val h = b.height * fit
        val cx = width / 2f + offsetX
        val cy = height / 2f + offsetY
        val save = canvas.save()
        canvas.rotate(rotationDegrees, cx, cy)
        val dst = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        paint.alpha = (alphaValue * 255).toInt()
        canvas.drawBitmap(b, null, dst, paint)
        canvas.restoreToCount(save)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isLocked) return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; lastY = event.y; return true }
            MotionEvent.ACTION_MOVE -> {
                offsetX += event.x - lastX
                offsetY += event.y - lastY
                lastX = event.x; lastY = event.y
                invalidate()
                return true
            }
        }
        return true
    }
}
