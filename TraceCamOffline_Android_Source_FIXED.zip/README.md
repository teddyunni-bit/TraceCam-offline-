# TraceCam Offline (Android source project)

An offline Android camera tracing app. It shows the live rear-camera preview with a gallery image drawn transparently on top.

## Features
- Choose an image using Android's system photo/document picker.
- Live camera preview with transparent image overlay.
- Transparency slider, image-size slider, drag to position, rotate buttons, reset and lock.
- No `INTERNET` permission in AndroidManifest.xml. The app itself does not request network access.

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Let Gradle download the Android build tools/plugin dependencies on the computer for the initial build.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone.

The installed app does not need internet. Initial project setup/build may need internet to fetch Android Gradle Plugin and Kotlin plugin dependencies. The camera requires permission. Gallery access is through Android's system picker.

## Notes
- This is a starter project; test on your specific phone and Android version.
- The overlay is aligned relative to the phone screen, not physically stabilized to the paper. A phone stand helps keep the view steady.
- The first version includes drag, size, transparency, rotate, lock, and reset. Pinch-to-zoom and save/export are not implemented yet.
